﻿import React from "react";

export default function Body () {
  return (
    <div className="text-center p-5">
      <h3>Body  – coming soon…</h3>
    </div>
  );
}
