﻿import React from "react";

export default function Brainstorm () {
  return (
    <div className="text-center p-5">
      <h3>Brainstorm  – coming soon…</h3>
    </div>
  );
}
