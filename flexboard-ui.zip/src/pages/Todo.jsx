﻿import React from "react";

export default function Todo () {
  return (
    <div className="text-center p-5">
      <h3>Todo  – coming soon…</h3>
    </div>
  );
}
