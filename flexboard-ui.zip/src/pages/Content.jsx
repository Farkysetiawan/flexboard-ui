﻿import React from "react";

export default function Content () {
  return (
    <div className="text-center p-5">
      <h3>Content  – coming soon…</h3>
    </div>
  );
}
