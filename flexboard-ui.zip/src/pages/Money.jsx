﻿import React from "react";

export default function Money () {
  return (
    <div className="text-center p-5">
      <h3>Money  – coming soon…</h3>
    </div>
  );
}
