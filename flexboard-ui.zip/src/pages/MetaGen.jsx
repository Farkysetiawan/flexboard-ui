﻿import React from "react";

export default function MetaGen () {
  return (
    <div className="text-center p-5">
      <h3>MetaGen  – coming soon…</h3>
    </div>
  );
}
