﻿import React from "react";

export default function Settings () {
  return (
    <div className="text-center p-5">
      <h3>Settings  – coming soon…</h3>
    </div>
  );
}
