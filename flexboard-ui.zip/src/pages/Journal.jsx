﻿import React from "react";

export default function Journal () {
  return (
    <div className="text-center p-5">
      <h3>Journal  – coming soon…</h3>
    </div>
  );
}
