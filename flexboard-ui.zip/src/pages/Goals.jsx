﻿import React from "react";

export default function Goals () {
  return (
    <div className="text-center p-5">
      <h3>Goals  – coming soon…</h3>
    </div>
  );
}
