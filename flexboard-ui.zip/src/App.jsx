import "bootstrap/dist/css/bootstrap.min.css";
import React, { useState } from "react";
import { BrowserRouter, Routes, Route, useLocation, BrowserRouter as Router } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";

// Komponen global
import Topbar from "./components/Topbar";
import Sidebar from "./components/Sidebar";

// Halaman
import Dashboard from "./pages/Dashboard";
import Money from "./pages/Money";
import Body from "./pages/Body";
import Content from "./pages/Content";
import Todo from "./pages/Todo";
import Goals from "./pages/Goals";
import Journal from "./pages/Journal";
import MetaGen from "./pages/MetaGen";
import Brainstorm from "./pages/Brainstorm";
import Quicklinks from "./pages/Quicklinks";

// Animasi transisi halaman (dari bawah ke atas)
function AnimatedPage({ children }) {
  const location = useLocation();
  return (
    <motion.div
      key={location.pathname}
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.45, ease: [0.4, 0, 0.2, 1] }}
    >
      {children}
    </motion.div>
  );
}

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<AnimatedPage><Dashboard /></AnimatedPage>} />
        <Route path="/money" element={<AnimatedPage><Money /></AnimatedPage>} />
        <Route path="/quicklinks" element={<AnimatedPage><Quicklinks /></AnimatedPage>} />
        <Route path="/body" element={<AnimatedPage><Body /></AnimatedPage>} />
        <Route path="/content" element={<AnimatedPage><Content /></AnimatedPage>} />
        <Route path="/todo" element={<AnimatedPage><Todo /></AnimatedPage>} />
        <Route path="/goals" element={<AnimatedPage><Goals /></AnimatedPage>} />
        <Route path="/journal" element={<AnimatedPage><Journal /></AnimatedPage>} />
        <Route path="/metagen" element={<AnimatedPage><MetaGen /></AnimatedPage>} />
        <Route path="/brainstorm" element={<AnimatedPage><Brainstorm /></AnimatedPage>} />
        <Route path="*" element={<h2>Not Found</h2>} />
      </Routes>
    </AnimatePresence>
  );
}

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const sidebarWidth = sidebarOpen ? 220 : 60;

  return (
    <Router>
      <Topbar onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />
      <div
        className="d-flex"
        style={{ paddingTop: "56px", minHeight: "100vh", background: "#f8f9fa" }}
      >
        {/* Sidebar geser dari kiri */}
        <Sidebar collapsed={!sidebarOpen} />

        {/* Konten utama tetap smooth dari bawah ke atas */}
        <motion.div
          className="flex-grow-1"
          animate={{ marginLeft: sidebarWidth }}
          transition={{ duration: 0.45, ease: [0.4, 0, 0.2, 1] }}
          style={{ padding: "1.5rem" }}
        >
          <AnimatedRoutes />
        </motion.div>
      </div>
    </Router>
  );
}
