// src/components/Sidebar.jsx
import React from "react";
import { Nav } from "react-bootstrap";
import {
  BsLightningChargeFill,
  BsWallet2,
  BsHeartPulse,
  BsTable,
  BsCheck2Square,
  BsFlag,
  BsJournal,
  BsStars,
  BsLightbulb
} from "react-icons/bs";
import { motion } from "framer-motion";

const links = [
  { to: "/",           icon: <BsLightningChargeFill />, label: "Dashboard" },
  { to: "/money",      icon: <BsWallet2 />,              label: "Money Tracker" },
  { to: "/quicklinks", icon: <BsLightningChargeFill />, label: "Quicklinks" },
  { to: "/body",       icon: <BsHeartPulse />,           label: "Body Tracker" },
  { to: "/content",    icon: <BsTable />,                label: "Content Mgr" },
  { to: "/todo",       icon: <BsCheck2Square />,         label: "To-do List" },
  { to: "/goals",      icon: <BsFlag />,                 label: "Goals" },
  { to: "/journal",    icon: <BsJournal />,              label: "Journal" },
  { to: "/metagen",    icon: <BsStars />,                label: "MetaGen" },
  { to: "/brainstorm", icon: <BsLightbulb />,            label: "Brainstorm" }
];

export default function Sidebar({ collapsed }) {
  return (
    <motion.div
      className={`sidebar d-flex flex-column pt-4 border-end bg-white ${collapsed ? "collapsed" : ""}`}
      initial={{ x: -250 }}
      animate={{ x: collapsed ? -250 : 0 }}
      transition={{ type: "tween", duration: 0.4 }}
      style={{
        height: "100vh",
        position: "fixed",
        width: collapsed ? "60px" : "220px"
      }}
    >
      <Nav className="flex-column">
        {links.map((l) => (
          <Nav.Link
            key={l.to}
            href={l.to}
            className="d-flex align-items-center gap-3 py-2 px-3 link-dark"
            style={{
              transition: "all 0.2s ease",
              fontWeight: 500
            }}
            onMouseEnter={(e) => {
              const icon = e.currentTarget.querySelector("svg");
              icon.style.transform = "scale(1.3)";
              icon.style.color = "#0d6efd";
              e.currentTarget.style.backgroundColor = "#f1f3f5";
              e.currentTarget.style.borderRadius = "0.375rem";
            }}
            onMouseLeave={(e) => {
              const icon = e.currentTarget.querySelector("svg");
              icon.style.transform = "scale(1)";
              icon.style.color = "#6c757d";
              e.currentTarget.style.backgroundColor = "transparent";
            }}
          >
            <span
              style={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                width: "24px"
              }}
            >
              {React.cloneElement(l.icon, {
                size: 18,
                style: {
                  color: "#6c757d",
                  transition: "all 0.2s ease"
                }
              })}
            </span>
            <span className="link-label flex-grow-1">{l.label}</span>
          </Nav.Link>
        ))}
      </Nav>
    </motion.div>
  );
}
