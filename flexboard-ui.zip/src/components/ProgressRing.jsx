// src/components/ProgressRing.jsx
export default function ProgressRing({ value = 67 }) {
  return <h2>Progress: {value}% (placeholder)</h2>;
}
